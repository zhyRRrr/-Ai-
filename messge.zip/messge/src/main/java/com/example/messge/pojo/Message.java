package com.example.messge.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Table(name = "messages")
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    声明与Chat的多对一关系
    @ManyToOne
//    关联列为chat_id
    @JoinColumn(name = "chat_id", nullable = false)
//    忽略序列化以避免无限递归。
    @JsonIgnore
    private Chat chat;

    private String sender;
    private String receiver;
    // 添加问题字段
    private String question;

    // 添加答案字段
    private String answer;
    private LocalDateTime timestamp;
    // 新增字段用于保存关键词
    @ElementCollection
    private List<String> keywords = new ArrayList<>(); // 保存提取的关键词
}
