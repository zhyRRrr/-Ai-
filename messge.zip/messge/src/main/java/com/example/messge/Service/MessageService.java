package com.example.messge.Service;

import com.example.messge.Repository.ChatRepository;
import com.example.messge.Repository.MessageRepository;
import com.example.messge.pojo.Chat;
import com.example.messge.pojo.Message;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MessageService {
    private final MessageRepository messageRepository;
    private final ChatRepository chatRepository;

    public Message saveMessage(Long chatId, String sender, String receiver, String question, String answer) {
        Chat chat = chatRepository.findById(chatId)
                .orElseThrow(() -> new RuntimeException("聊天没有找到"));

        Message message = new Message();
        message.setChat(chat);
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setQuestion(question); // 保存问题
        message.setAnswer(answer);     // 保存答案
        message.setTimestamp(LocalDateTime.now());

        return messageRepository.save(message);
    }

    public List<String> getKeywordsBySender(String sender) {
        List<Message> messages = messageRepository.findBySender(sender);
        return messages.stream()
                .flatMap(message -> message.getKeywords().stream())
                .collect(Collectors.toList());
    }

    public List<Message> getMessagesByChatId(Long chatId) {
        return messageRepository.findByChatId(chatId);
    }
}
